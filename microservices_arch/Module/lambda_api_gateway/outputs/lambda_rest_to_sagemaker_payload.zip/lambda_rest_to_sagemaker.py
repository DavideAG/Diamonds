def hello_handler(event, context):
    print('hello')